#include "metric.h"
#include "auxFunctions.h"

double electronDensity(double, double);
