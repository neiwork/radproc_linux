#include "torusSampling.h"

int main()
{
  torusSampling(); 
  return 0;
}
