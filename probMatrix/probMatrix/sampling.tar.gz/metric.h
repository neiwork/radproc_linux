double g_tt(double, double);
double g_rr(double, double);
double g_thetatheta(double, double);
double g_tphi(double, double);
double g_phiphi(double, double);
