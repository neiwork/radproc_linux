#include <time.h>
#include <stdlib.h>

#include "torusParameters.h"

void torusSampling();
