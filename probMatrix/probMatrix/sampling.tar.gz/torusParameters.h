#include "bisection.h"
#include "metric.h"
#include "auxFunctions.h"

double rCusp, rCenter, l_0;

double w(double, double);
double edge();
