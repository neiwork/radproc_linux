#include "torusSampling.h"
#include <stdio.h>

extern double rMin, rCenter, l_0;
extern double spinBH, lambda;

void torusSampling()
{
  criticalRadii(&rMin, &rCenter);
  l_0 = specificAngularMom();
  double rMax = edge();

  printf("rMin = %f\n", rMin);
  printf("rCenter = %f\n", rCenter);
  printf("rMax = %f\n", rMax);
  printf("l_0 = %f\n", l_0);
  printf("potential at surface = %f\n", w(rMin,0.0));
  printf("potential at center = %f\n", w(rCenter,0.0));
  printf("potential at edge = %f\n", w(rMax,0.0));
  printf("potential in (rMax+rCenter)/2 = %f\n", w(0.5*(rMax+rCenter),0.0));
  printf("potential outside the torus = %f\n", w(rMax*1.5, 0.0));

  FILE *fp;
  fp = fopen("Output.txt", "w");

  int points = 10000;
  int i=0;
  srand((unsigned)time(NULL));
  while (i<points) {
    double rRand = (double)(rand())/RAND_MAX * (rMax-rMin) + rMin;
    double zMax = rMax + 3.0*rMax*lambda;
    double zRand = (double)(rand()) / RAND_MAX * zMax;
    double thetaRand = atan( zRand / rRand);
      
    if (w(rRand, thetaRand) > 0) {
      fprintf(fp, "%f   %f\n", rRand, zRand);
      fprintf(fp, "%f   %f\n", rRand, -zRand);
      fprintf(fp, "%f   %f\n", -rRand, zRand);
      fprintf(fp, "%f   %f\n", -rRand, -zRand);
      i++;
    }
  }
  fclose(fp);
}
