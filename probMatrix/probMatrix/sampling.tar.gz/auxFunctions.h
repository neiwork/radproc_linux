#include "metric.h"
#include "bisection.h"

extern double massBH, spinBH, lambda;

void criticalRadii(double *, double *);
double specificAngularMom();
