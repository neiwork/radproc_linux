#include <stdio.h>
#include <math.h>

double bisection(double , double, double, int, double (*f)(double));
